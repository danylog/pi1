/**
 * Praktikum Informatik 1 
 * 
 *
 * @file test.h
 *
 * Stellt eine Funktion zum Testen der Spielfunktionen bereit
 */
#ifndef TEST_H_
#define TEST_H_

bool ganzenTestAusfuehren();

#endif /* TEST_H_ */
